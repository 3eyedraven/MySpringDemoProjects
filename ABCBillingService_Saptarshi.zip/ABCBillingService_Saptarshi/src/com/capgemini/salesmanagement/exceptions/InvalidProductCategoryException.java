package com.capgemini.salesmanagement.exceptions;

public class InvalidProductCategoryException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductCategoryException() {
		System.out.println("Product Category is Invalid!");
	}

}
