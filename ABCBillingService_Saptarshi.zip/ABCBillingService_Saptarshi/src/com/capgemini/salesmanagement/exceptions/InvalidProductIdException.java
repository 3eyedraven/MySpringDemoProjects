package com.capgemini.salesmanagement.exceptions;

public class InvalidProductIdException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductIdException() {
		System.out.println("Product Id is Invalid");
	}

}
