package com.capgemini.salesmanagement.exceptions;

public class InvalidProductNameException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductNameException() {
		System.out.println("Product Name is Invalid!");
	}
}
