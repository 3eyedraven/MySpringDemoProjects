package com.capgemini.salesmanagement.exceptions;

public class InvalidProductPriceException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductPriceException() {
		System.out.println("Product Price is Invalid!");
	}

}
