package com.capgemini.salesmanagement.dao;

import java.time.LocalDate;
import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {

	@Override
	public Sale insertSalesDetails(Sale sale) {
		sale.setSaleId(CollectionUtil.getSALE_ID());
		sale.setSaleDate(LocalDate.now());
		CollectionUtil.sales.put(sale.getSaleId(), sale);
		return sale;
	}

}
