package com.capgemini.salesmanagement.service;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductIdException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidProductQuantityException;

public class SaleService implements ISaleService {
	private ISaleDAO saleDao=new SaleDAO();
	public SaleService() {}
	@Override
	public Sale insertSalesDetails(int prodCode, String productName, String category, float prodPrice)
			throws InvalidProductIdException, InvalidProductNameException, InvalidProductPriceException,
			InvalidProductCategoryException {
		Sale sale=new Sale(prodCode,productName,category,prodPrice);
		if (validateProductCode(prodCode)==true || validateProductName(productName)==true || validateProductCat(category)==true || validateProductPrice(prodPrice)==true)
		sale=saleDao.insertSalesDetails(sale);
		return sale;
	}
	@Override
	public float CalculatePrice(float prodPrice, int quantity)
	{
		float price=0;
		price=quantity*prodPrice;
		return price;
	}
	@Override
	public boolean validateProductCode(int productId) throws InvalidProductIdException {
		if (productId==1001 || productId==1002 || productId==1003 || productId==1004)
			return true;
		else throw new InvalidProductIdException();
	}
	@Override
	public boolean validateQuantity(int quantity) throws InvalidProductQuantityException {
		if (quantity>0 && quantity <5)
			return true;
		else throw new InvalidProductQuantityException();
	}
	@Override
	public boolean validateProductCat(String category) throws InvalidProductCategoryException {
		if (category.equals("Electronics") || category.equals("Toys"))
			return true;
		else throw new InvalidProductCategoryException();
	}
	@Override
	public boolean validateProductName(String productName) throws InvalidProductNameException {
		if (productName.equals("TV") || productName.equals("Smart Phone") || productName.equals("Video Games") || productName.equals("Soft Toy") || productName.equals("Telescope") || productName.equals("Barbee Doll"))
			return true;
		else throw new InvalidProductNameException();
	}
	@Override
	public boolean validateProductPrice(float prodPrice) throws InvalidProductPriceException {
		if (prodPrice>200)
			return true;
		else throw new InvalidProductPriceException();
	}

	
}
