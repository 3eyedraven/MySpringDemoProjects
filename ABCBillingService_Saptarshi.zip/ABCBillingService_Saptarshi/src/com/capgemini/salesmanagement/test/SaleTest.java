package com.capgemini.salesmanagement.test;

public class SaleTest {

}
