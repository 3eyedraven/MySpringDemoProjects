package com.capgemini.salesmanagement.service;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductIdException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidProductQuantityException;

public interface ISaleService {
	public Sale insertSalesDetails(int prodCode, String productName, String category, float prodPrice)
				throws InvalidProductIdException, InvalidProductNameException, InvalidProductPriceException, InvalidProductCategoryException;
	public float CalculatePrice(float prodPrice, int quantity) throws InvalidProductQuantityException;
	public boolean validateProductCode(int prodCode) throws InvalidProductIdException;
	boolean validateQuantity(int quantity) throws InvalidProductQuantityException;
	public boolean validateProductCat(String category) throws InvalidProductCategoryException;
	public boolean validateProductName(String productName) throws InvalidProductNameException;
	public boolean validateProductPrice(float prodPrice) throws InvalidProductPriceException;
	

}
