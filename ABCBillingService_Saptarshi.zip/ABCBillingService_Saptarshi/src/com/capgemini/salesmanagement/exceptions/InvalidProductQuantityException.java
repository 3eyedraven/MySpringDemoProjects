package com.capgemini.salesmanagement.exceptions;

public class InvalidProductQuantityException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductQuantityException() {
		System.out.println("Product Quantity is Invalid!");
	}

}
