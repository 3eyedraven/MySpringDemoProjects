package com.capgemini.salesmanagement.ui;

import java.util.Scanner;

import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductIdException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {

	public static void main(String[] args) throws InvalidProductIdException, InvalidProductNameException, InvalidProductPriceException, InvalidProductCategoryException {
		SaleService saleService=new SaleService();
		System.out.println(saleService.insertSalesDetails(1001, "TV", "Electronics", 220));
		System.out.println("Enter Product Quantity:");
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		int q=sc.nextInt();
		System.out.println("Enter Product Price:");
		int prodPrice=sc.nextInt();
		System.out.println(saleService.toString());
		System.out.println("Your Bill is: "+calculatePrice(q,prodPrice));
		
	}
	public static float calculatePrice(int quantity, float prodPrice)
	{
		return (float)prodPrice*quantity;
	}

}
