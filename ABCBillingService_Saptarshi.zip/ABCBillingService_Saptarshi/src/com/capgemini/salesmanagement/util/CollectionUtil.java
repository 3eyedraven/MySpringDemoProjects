package com.capgemini.salesmanagement.util;

import java.util.HashMap;
import com.capgemini.salesmanagement.bean.Sale;

public class CollectionUtil {
	public static HashMap<Integer,Sale> sales = new HashMap<Integer, Sale>();
	public static int getSALE_ID() {
		return ((int)Math.random()*100+1);
	}
	public static HashMap<Integer,Sale> getCollection(){
		return sales;
		
	}

}
