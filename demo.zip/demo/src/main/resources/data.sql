INSERT INTO swords(name, power) VALUES('Ordinary Steel', 1);
INSERT INTO swords(name, power) VALUES('Pure Steel', 1.5);
INSERT INTO swords(name, power) VALUES('Witcher Steel 1', 2.5);
INSERT INTO swords(name, power) VALUES('Witcher Steel 2', 3);

COMMIT;